package com.ltg.framework.constants;

/**
 * nekoimi  2021/7/19 下午12:02
 */
public interface RequestAttributeConstants {
    String REQUEST_USER = "CURRENT_OPERATOR";
}
