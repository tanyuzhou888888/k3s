package com.ltg.framework.error.exception;

/**
 * <p> ClassName: BunsinessException </p>
 * <p> Package: com.ltg.framework.error.exception </p>
 * <p> Description: </p>
 * <p></p>
 *
 * @Author: LTG
 * @Create: 2023/1/7 - 20:31
 * @Version: v1.0
 */
public class BusinessException extends BaseException{


    public BusinessException(String message) {
        super(message);
    }


}
