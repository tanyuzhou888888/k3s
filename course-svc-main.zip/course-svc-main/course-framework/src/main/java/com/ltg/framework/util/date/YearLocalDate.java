package com.ltg.framework.util.date;

/**
 * <p> ClassName: YearDate </p>
 * <p> Package: com.ltg.framework.util.date </p>
 * <p> Description: </p>
 * <p></p>
 *
 * @Author: LTG
 * @Create: 2023/2/7 - 22:39
 * @Version: v1.0
 */
public class YearLocalDate {
}
