# course-svc 选课系统

## 模块

* course-framework 基础框架
* course-file 文件
* course-login 
    course-login-api
* course-consumer-course 
* 基础业务模块:包括登录、注册、发布课程、选课功能
* course-consumer-order 基础业务模块:包括登录、注册、发布课程、选课功能
* course-admin-server 基础业务模块:包括登录、注册、发布课程、选课功能
