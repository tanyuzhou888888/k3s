package com.ltg.base.file.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ltg.base.file.entity.FileInfo;

/**
 * <p> ClassName: FileInfoMapper </p>
 * <p> Package: com.ltg.file.mapper </p>
 * <p> Description: </p>
 * <p></p>
 *
 * @Author: LTG
 * @Create: 2023/2/13 - 17:41
 * @Version: v1.0
 */
public interface FileInfoMapper extends BaseMapper<FileInfo> {
}
